# Pacha Design System

Pacha is a pre-seed, Nairobi-based startup building **AI-native back-office automation for insurance claims**. Founded by Aryia Patel, Pacha turns an FNOL (first notice of loss) into a complete, approval-ready claims pack — automating the ~90% of claims-handling work that is document transport and rules-checking, so human claims professionals spend their time on the ~10% that is genuine judgement. The company is paid per claim processed (not per seat, not per hour), starting with Kenyan motor and medical insurers before expanding into UK claims BPO and, eventually, AI-native insurance products.

**Source material.** This design system was built entirely from one document: `uploads/Pacha - Antler Deck (2).pdf`, a 14-page pitch deck (Canva-authored, dated July 2026) covering Problem, Solution, Opportunity, Business Model, Why Now, GTM, Competition, and Team & Ask. No Figma file, codebase, or product screenshots were provided or are known to exist — Pacha is pre-MVP ("Complete the MVP and run the first live claims pilot" is a stated near-term goal). Everything below — palette, type, motifs — is reverse-engineered from that deck's embedded fonts, images, and layout. **There is no existing Pacha product UI to recreate**, so this system ships foundations + a general-purpose component set + a slide template, not a UI kit. If a Figma file, repo, or live product is shared later, re-run this process against it — the deck-derived palette should be treated as a strong starting point, not gospel.

## Content fundamentals

- **Voice:** first-person founder narration, direct and evidence-led. The deck opens with *"I spent weeks on the claims floor of a Kenyan insurer. This is what I measured"* — claims are backed by specifics (percentages, currency figures, timeframes), not adjectives.
- **Sentence rhythm:** short, declarative, often fragments for emphasis: *"Agents Execute. Software Validates. Claims Professionals Decide."* and *"We don't sell a tool. We do the work."* Contrast pairs are a recurring device ("Not per seat. Not per hour.").
- **Casing:** slide titles and nav labels are Title Case or Sentence case single words ("Problem", "Solution", "Business Model"). Body copy is standard sentence case. Section numbers are rendered in parens in mono type: `(01)`, `(02)`.
- **Numbers carry the argument.** Stats are large and central, not decorative — `(70%)`, `KES 67.6bn`, `93.08%` gross margin. Cite the derivation in small print when a number could be doubted (see slide 6: "Derivation: claims paid (IRA, ABI 2024/25) × industry benchmarks").
- **No emoji, no exclamation points, no hedging language.** The tone is operator-credible, not hype-y — this reads like someone who has actually shadowed a claims floor, not a generic AI pitch.
- **Pronouns:** "we" for the company, second person is rare (this is an investor narrative, not direct marketing copy) — if writing product/marketing copy, prefer "you" for the customer (the insurer/MGA) and keep the same evidence-first tone.

## Visual foundations

- **Palette:** cool, professional blue (`--color-primary`, sampled from the deck's ambient gradients) as the primary brand color, on a white canvas with near-black text. A secondary palette of soft pastel accents (teal, coral, pink, periwinkle, sage, butter) appears exclusively inside blurred gradient "orbs" — never as flat fills, text color, or UI chrome. Treat the pastels as atmosphere, the blue as the only "loud" brand color, and black/white/gray as the workhorse UI palette.
- **Type:** three families, each with one job.
  - **Ovo** (serif, regular weight only) — display headlines and slide titles. Used at large sizes, always regular weight (no bold cut exists), sentence-cased.
  - **Courier Prime** (monospace) — numbers, stats, section numbering `(01)`, data tables, and anything meant to read as "measured fact."
  - **Canva Sans** (Bold + Regular) — body copy and UI text in the source deck. **Canva Sans is Canva's proprietary font and isn't distributable** — this system uses **Segoe UI** (with system-font fallbacks) as the UI/body sans.
- **Backgrounds:** flat white, decorated with large, softly blurred radial/organic gradient shapes ("orbs") bleeding off the canvas edge — never a hard-edged color block. A subtle monochrome grain-wave texture appears at low opacity in some sections (see the closing slide), giving the flat white a bit of tooth. No photography, no line illustrations, no icon system, and no separate logo symbol — **the logo is the "Pacha" wordmark itself, always set in Ovo** (confirmed by the founder).
- **Layout:** generous negative space, left-aligned text blocks, a consistent small-caps mono header (`2026 PACHA`) top of every slide, and a numbered section index. Numbers/labels in parens double as light navigation.
- **Animation & states:** the source deck is static (no motion to observe). This system defines a conservative, non-bouncy motion system for the components built on top: 120–360ms, standard ease-out curves, no springs, no bounce — matching the brand's measured, non-hypey tone.
- **Hover/press states:** components in this kit darken (primary buttons) or tint gray (secondary/ghost) on hover, and scale to 0.98 on press — no shadows-on-hover, no color inversion.
- **Borders & shadows:** hairline 1px borders (`--border-subtle` / `--border-default`) in gray, paired with very soft, low-spread shadows (`--shadow-sm`/`md`/`lg`). No colored borders, no left-border-accent cards.
- **Corner radii:** not defined by the source (it has no UI chrome) — this system uses a modest 6/10/16/24px scale, flagged as an intentional addition for product UI.
- **Transparency/blur:** the deck uses semi-transparent gradient PNGs (alpha-blended orbs) and a screen-blended grain overlay; no glass/blur-panel UI chrome was observed.
- **Imagery color vibe:** N/A — no photography in the source. The only imagery is the abstract gradient orbs (cool blues/teals contrasted with warm coral/pink/peach/olive accents) and a monochrome grain texture.

## Iconography

**No icon system, icon font, SVG set, or unicode-icon convention appears anywhere in the source deck** — it is 100% typographic (headlines, body copy, numbers, one small table). No icons were copied in and none should be invented. If/when Pacha needs icons (e.g. for a product UI), the recommended path is a CDN icon set matching this system's restrained, non-illustrative tone — **Lucide** (clean single-weight line icons) is a reasonable default; flag this as a substitution when first used, since it is not sourced from Pacha material.

## Font substitution — needs your input

**Canva Sans** (the deck's body/UI font, weights Bold + Regular) is Canva's proprietary typeface and has no public distribution — it cannot be extracted from the PDF as a reusable webfont. This system uses **Segoe UI** in its place (a system font, so no webfile ships; it falls back to the platform UI sans on non-Windows devices). If you'd prefer a bundled webfont instead, share it and `--font-sans` in `tokens/typography.css` can be updated in one pass.

## Index

```
styles.css                 → single import entrypoint (tokens only, no rules)
tokens/
  colors.css                blue scale, pastel accents, neutrals, semantic aliases
  typography.css             font families, type scale, weights, tracking/leading
  effects.css                 radius, shadow, easing/duration tokens
  fonts.css                    @font-face — Ovo, Courier Prime, Inter (local files)
assets/
  fonts/                      woff2 files backing tokens/fonts.css
  gradients/                  8 ambient gradient PNGs + 1 grain texture, extracted from the deck
components/
  core/Button
  forms/Input, Select, Checkbox, Switch
  data/Card, Badge
  navigation/Tabs
  feedback/Dialog, Toast
guidelines/                   14 foundation specimen cards (Colors/Type/Spacing/Brand groups)
  slides/                      5 sample slide layouts (group "Slides") echoing the deck's own style
uploads/pacha-deck.pdf        source deck (renamed copy of the original upload)
SKILL.md                      Claude-Code-portable skill wrapper for this system
```

**Intentional additions** (not sourced from the deck, added because a functioning UI needs them): the entire `components/` set (Button, Input, Select, Checkbox, Switch, Card, Badge, Tabs, Dialog, Toast) — the deck defines no UI components at all, so a standard set was authored sized to an insurance-ops product; the radius/shadow/spacing/motion scales in `tokens/effects.css`; the semantic state colors (success/warning/danger/info) which have no deck precedent.

## Caveats & what would make this better

- **No product UI exists yet.** Every component above is a from-scratch, brand-appropriate primitive, not a recreation — there was nothing to recreate. Once a Figma file or live product exists, this is the first thing to redo against real screens.
- **Canva Sans → Inter substitution** (see above) needs your confirmation or real font files.
- **The logo is the "Pacha" wordmark** set in Ovo — confirmed by the founder. There is no separate symbol/mark; render the wordmark in Ovo wherever a logo is needed.
- **Palette is inferred from decorative gradients**, not a documented brand palette — treat blue as confident (it's the dominant, repeated color) and the pastel accents as a looser starting point.

**Please iterate with me:** tell me what's off, and I'll refine it — more/different components, a real logo, corrected fonts, a UI kit once you have product screens, tighter alignment to any brand guidelines you're working from internally.
