/* @ds-bundle: {"format":4,"namespace":"PachaDesignSystem_da00b1","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Badge","sourcePath":"components/data/Badge.jsx"},{"name":"Card","sourcePath":"components/data/Card.jsx"},{"name":"Dialog","sourcePath":"components/feedback/Dialog.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Button.jsx":"d91f80186105","components/data/Badge.jsx":"e134658d3c78","components/data/Card.jsx":"a229bbde1a9c","components/feedback/Dialog.jsx":"4c973ecc0a94","components/feedback/Toast.jsx":"39a798e4fcfc","components/forms/Checkbox.jsx":"7f1683cae17b","components/forms/Input.jsx":"32933aa02303","components/forms/Select.jsx":"f10dcee1747d","components/forms/Switch.jsx":"f7950cc38b51","components/navigation/Tabs.jsx":"705d54ab6690"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PachaDesignSystem_da00b1 = window.PachaDesignSystem_da00b1 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Button.jsx
try { (() => {
const sizes = {
  sm: {
    padding: '8px 14px',
    fontSize: 'var(--text-body-sm)',
    gap: 6,
    height: 36
  },
  md: {
    padding: '10px 18px',
    fontSize: 'var(--text-body-md)',
    gap: 8,
    height: 44
  },
  lg: {
    padding: '14px 24px',
    fontSize: 'var(--text-body-lg)',
    gap: 10,
    height: 52
  }
};
function variantStyle(variant, disabled) {
  if (disabled) {
    return {
      background: 'var(--gray-100)',
      color: 'var(--gray-400)',
      border: '1px solid var(--gray-200)'
    };
  }
  switch (variant) {
    case 'secondary':
      return {
        background: 'var(--white)',
        color: 'var(--text-primary)',
        border: '1px solid var(--border-default)'
      };
    case 'ghost':
      return {
        background: 'transparent',
        color: 'var(--text-primary)',
        border: '1px solid transparent'
      };
    case 'danger':
      return {
        background: 'var(--state-danger)',
        color: 'var(--white)',
        border: '1px solid var(--state-danger)'
      };
    default:
      return {
        background: 'var(--color-primary)',
        color: 'var(--text-on-primary)',
        border: '1px solid var(--color-primary)'
      };
  }
}
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  children,
  onClick,
  type = 'button',
  style
}) {
  const s = sizes[size] || sizes.md;
  const v = variantStyle(variant, disabled);
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  let bg = v.background;
  if (!disabled && hover) {
    if (variant === 'secondary') bg = 'var(--gray-50)';else if (variant === 'ghost') bg = 'var(--gray-100)';else if (variant === 'danger') bg = '#a83733';else bg = 'var(--color-primary-hover)';
  }
  if (!disabled && active) {
    if (variant === 'secondary') bg = 'var(--gray-100)';else if (variant === 'ghost') bg = 'var(--gray-200)';else if (variant === 'danger') bg = '#8c2d29';else bg = 'var(--color-primary-active)';
  }
  return /*#__PURE__*/React.createElement("button", {
    type: type,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: s.gap,
      padding: s.padding,
      height: s.height,
      fontSize: s.fontSize,
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-semibold)',
      borderRadius: 'var(--radius-md)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      transition: `background var(--duration-fast) var(--ease-standard), transform var(--duration-fast) var(--ease-standard)`,
      transform: active && !disabled ? 'scale(0.98)' : 'scale(1)',
      ...v,
      background: bg,
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/data/Badge.jsx
try { (() => {
const tones = {
  neutral: {
    bg: 'var(--gray-100)',
    fg: 'var(--gray-700)'
  },
  primary: {
    bg: 'var(--color-primary-subtle)',
    fg: 'var(--blue-700)'
  },
  success: {
    bg: 'var(--state-success-subtle)',
    fg: 'var(--state-success)'
  },
  warning: {
    bg: 'var(--state-warning-subtle)',
    fg: 'var(--coral-700)'
  },
  danger: {
    bg: 'var(--state-danger-subtle)',
    fg: 'var(--state-danger)'
  }
};
function Badge({
  children,
  tone = 'neutral'
}) {
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '3px 10px',
      borderRadius: 'var(--radius-pill)',
      fontFamily: 'var(--font-mono)',
      fontSize: 'var(--text-caption)',
      letterSpacing: 'var(--tracking-wide)',
      textTransform: 'uppercase',
      fontWeight: 'var(--weight-bold)',
      background: t.bg,
      color: t.fg
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data/Card.jsx
try { (() => {
function Card({
  children,
  padding = 'md',
  style,
  elevated = false
}) {
  const pad = padding === 'sm' ? 16 : padding === 'lg' ? 32 : 24;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      padding: pad,
      border: '1px solid var(--border-subtle)',
      boxShadow: elevated ? 'var(--shadow-md)' : 'var(--shadow-sm)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Card.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Dialog.jsx
try { (() => {
function Dialog({
  open,
  title,
  children,
  onClose,
  footer
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(10,10,12,0.45)',
      backdropFilter: 'blur(2px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      fontFamily: 'var(--font-sans)'
    },
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: 'var(--surface-card)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-lg)',
      width: 420,
      maxWidth: '90vw',
      padding: 28,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, title && /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--text-heading-md)',
      fontWeight: 'var(--weight-regular)',
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-secondary)',
      lineHeight: 'var(--leading-normal)'
    }
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 12
    }
  }, footer)));
}
Object.assign(__ds_scope, { Dialog });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Dialog.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
const tones = {
  info: {
    bg: 'var(--gray-950)',
    accent: 'var(--blue-400)'
  },
  success: {
    bg: 'var(--gray-950)',
    accent: 'var(--state-success)'
  },
  danger: {
    bg: 'var(--gray-950)',
    accent: 'var(--state-danger)'
  }
};
function Toast({
  tone = 'info',
  message,
  onDismiss
}) {
  const t = tones[tone] || tones.info;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      background: t.bg,
      color: 'var(--text-on-inverse)',
      padding: '14px 18px',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-lg)',
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--text-body-sm)',
      minWidth: 280,
      borderLeft: `3px solid ${t.accent}`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, message), onDismiss && /*#__PURE__*/React.createElement("button", {
    onClick: onDismiss,
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--gray-400)',
      cursor: 'pointer',
      fontSize: 16,
      lineHeight: 1
    }
  }, "\xD7"));
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  label,
  checked = false,
  onChange,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 20,
      height: 20,
      borderRadius: 'var(--radius-sm)',
      flexShrink: 0,
      border: `1.5px solid ${checked ? 'var(--color-primary)' : 'var(--border-default)'}`,
      background: checked ? 'var(--color-primary)' : 'var(--white)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: `background var(--duration-fast) var(--ease-standard), border var(--duration-fast) var(--ease-standard)`
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--white)',
      fontSize: 13,
      lineHeight: 1
    }
  }, "\u2713")), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function Input({
  label,
  placeholder,
  value,
  onChange,
  type = 'text',
  error,
  helpText,
  disabled = false,
  size = 'md'
}) {
  const [focused, setFocused] = React.useState(false);
  const height = size === 'sm' ? 36 : size === 'lg' ? 52 : 44;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", {
    type: type,
    placeholder: placeholder,
    value: value,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      height,
      padding: '0 14px',
      borderRadius: 'var(--radius-md)',
      fontSize: 'var(--text-body-md)',
      fontFamily: 'var(--font-sans)',
      color: disabled ? 'var(--text-tertiary)' : 'var(--text-primary)',
      background: disabled ? 'var(--gray-50)' : 'var(--white)',
      border: `1px solid ${error ? 'var(--state-danger)' : focused ? 'var(--color-primary)' : 'var(--border-default)'}`,
      boxShadow: focused ? 'var(--shadow-focus)' : 'none',
      outline: 'none',
      transition: `border var(--duration-fast) var(--ease-standard), box-shadow var(--duration-fast) var(--ease-standard)`
    }
  }), (error || helpText) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-caption)',
      color: error ? 'var(--state-danger)' : 'var(--text-tertiary)'
    }
  }, error || helpText));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function Select({
  label,
  options = [],
  value,
  onChange,
  placeholder = 'Select…',
  disabled = false
}) {
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontFamily: 'var(--font-sans)',
      width: '100%'
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 'var(--text-body-sm)',
      fontWeight: 'var(--weight-semibold)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: value,
    disabled: disabled,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    style: {
      width: '100%',
      height: 44,
      padding: '0 36px 0 14px',
      borderRadius: 'var(--radius-md)',
      fontSize: 'var(--text-body-md)',
      fontFamily: 'var(--font-sans)',
      appearance: 'none',
      color: disabled ? 'var(--text-tertiary)' : 'var(--text-primary)',
      background: disabled ? 'var(--gray-50)' : 'var(--white)',
      border: `1px solid ${focused ? 'var(--color-primary)' : 'var(--border-default)'}`,
      boxShadow: focused ? 'var(--shadow-focus)' : 'none',
      outline: 'none',
      cursor: disabled ? 'not-allowed' : 'pointer'
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "",
    disabled: true,
    hidden: true
  }, placeholder), options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label))), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      right: 14,
      top: '50%',
      transform: 'translateY(-50%)',
      pointerEvents: 'none',
      color: 'var(--text-tertiary)',
      fontSize: 12
    }
  }, "\u25BE")));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function Switch({
  label,
  checked = false,
  onChange,
  disabled = false
}) {
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 10,
      fontFamily: 'var(--font-sans)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    onClick: () => !disabled && onChange && onChange(!checked),
    style: {
      width: 40,
      height: 24,
      borderRadius: 'var(--radius-pill)',
      flexShrink: 0,
      position: 'relative',
      background: checked ? 'var(--color-primary)' : 'var(--gray-300)',
      transition: `background var(--duration-base) var(--ease-standard)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 3,
      left: checked ? 19 : 3,
      width: 18,
      height: 18,
      borderRadius: '50%',
      background: 'var(--white)',
      boxShadow: 'var(--shadow-sm)',
      transition: `left var(--duration-base) var(--ease-standard)`
    }
  })), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--text-body-md)',
      color: 'var(--text-primary)'
    }
  }, label));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function Tabs({
  items = [],
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      borderBottom: '1px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)'
    }
  }, items.map(item => {
    const activeTab = item.value === value;
    return /*#__PURE__*/React.createElement("button", {
      key: item.value,
      onClick: () => onChange && onChange(item.value),
      style: {
        padding: '10px 4px',
        marginRight: 24,
        background: 'none',
        border: 'none',
        borderBottom: `2px solid ${activeTab ? 'var(--color-primary)' : 'transparent'}`,
        color: activeTab ? 'var(--text-primary)' : 'var(--text-tertiary)',
        fontWeight: activeTab ? 'var(--weight-semibold)' : 'var(--weight-medium)',
        fontSize: 'var(--text-body-md)',
        cursor: 'pointer',
        transition: `color var(--duration-fast) var(--ease-standard), border-color var(--duration-fast) var(--ease-standard)`
      }
    }, item.label);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Dialog = __ds_scope.Dialog;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
